﻿namespace CajeroForms
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txt50pesos = new System.Windows.Forms.TextBox();
            this.txt500pesos = new System.Windows.Forms.TextBox();
            this.txt200pesos = new System.Windows.Forms.TextBox();
            this.txt100pesos = new System.Windows.Forms.TextBox();
            this.txt1peso = new System.Windows.Forms.TextBox();
            this.txt2pesos = new System.Windows.Forms.TextBox();
            this.txt20pesos = new System.Windows.Forms.TextBox();
            this.txt10pesos = new System.Windows.Forms.TextBox();
            this.txt5pesos = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btn500b = new System.Windows.Forms.Button();
            this.btn20b = new System.Windows.Forms.Button();
            this.btn50b = new System.Windows.Forms.Button();
            this.btn2p = new System.Windows.Forms.Button();
            this.btn200b = new System.Windows.Forms.Button();
            this.btn1p = new System.Windows.Forms.Button();
            this.btn100b = new System.Windows.Forms.Button();
            this.btn5p = new System.Windows.Forms.Button();
            this.btn10p = new System.Windows.Forms.Button();
            this.labelIntroducido = new System.Windows.Forms.Label();
            this.labelTotal = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.existenciaSprite = new System.Windows.Forms.Label();
            this.codigoSprite = new System.Windows.Forms.Label();
            this.nombreSprite = new System.Windows.Forms.Label();
            this.precioSprite = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.existenciaPepper = new System.Windows.Forms.Label();
            this.codigoPepper = new System.Windows.Forms.Label();
            this.nombrePepper = new System.Windows.Forms.Label();
            this.precioPepper = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.existenciaCoca = new System.Windows.Forms.Label();
            this.codigoCoca = new System.Windows.Forms.Label();
            this.nombreCoca = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.precioCoca = new System.Windows.Forms.Label();
            this.imgDrPepper = new System.Windows.Forms.PictureBox();
            this.imgSprite = new System.Windows.Forms.PictureBox();
            this.imgCoca = new System.Windows.Forms.PictureBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.labelPantalla = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.labelMonedero = new System.Windows.Forms.Label();
            this.txtInput = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.labelDineroTotal = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgDrPepper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgSprite)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgCoca)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.labelDineroTotal);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txt50pesos);
            this.groupBox1.Controls.Add(this.txt500pesos);
            this.groupBox1.Controls.Add(this.txt200pesos);
            this.groupBox1.Controls.Add(this.txt100pesos);
            this.groupBox1.Controls.Add(this.txt1peso);
            this.groupBox1.Controls.Add(this.txt2pesos);
            this.groupBox1.Controls.Add(this.txt20pesos);
            this.groupBox1.Controls.Add(this.txt10pesos);
            this.groupBox1.Controls.Add(this.txt5pesos);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Font = new System.Drawing.Font("Nunito SemiBold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(12, 27);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(521, 568);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Dinero en caja";
            // 
            // txt50pesos
            // 
            this.txt50pesos.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt50pesos.Location = new System.Drawing.Point(173, 243);
            this.txt50pesos.Name = "txt50pesos";
            this.txt50pesos.ReadOnly = true;
            this.txt50pesos.Size = new System.Drawing.Size(314, 24);
            this.txt50pesos.TabIndex = 22;
            // 
            // txt500pesos
            // 
            this.txt500pesos.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt500pesos.Location = new System.Drawing.Point(173, 375);
            this.txt500pesos.Name = "txt500pesos";
            this.txt500pesos.ReadOnly = true;
            this.txt500pesos.Size = new System.Drawing.Size(314, 24);
            this.txt500pesos.TabIndex = 21;
            // 
            // txt200pesos
            // 
            this.txt200pesos.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt200pesos.Location = new System.Drawing.Point(173, 331);
            this.txt200pesos.Name = "txt200pesos";
            this.txt200pesos.ReadOnly = true;
            this.txt200pesos.Size = new System.Drawing.Size(314, 24);
            this.txt200pesos.TabIndex = 20;
            // 
            // txt100pesos
            // 
            this.txt100pesos.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt100pesos.Location = new System.Drawing.Point(173, 285);
            this.txt100pesos.Name = "txt100pesos";
            this.txt100pesos.ReadOnly = true;
            this.txt100pesos.Size = new System.Drawing.Size(314, 24);
            this.txt100pesos.TabIndex = 19;
            // 
            // txt1peso
            // 
            this.txt1peso.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt1peso.Location = new System.Drawing.Point(173, 42);
            this.txt1peso.Name = "txt1peso";
            this.txt1peso.ReadOnly = true;
            this.txt1peso.Size = new System.Drawing.Size(314, 24);
            this.txt1peso.TabIndex = 16;
            // 
            // txt2pesos
            // 
            this.txt2pesos.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt2pesos.Location = new System.Drawing.Point(173, 81);
            this.txt2pesos.Name = "txt2pesos";
            this.txt2pesos.ReadOnly = true;
            this.txt2pesos.Size = new System.Drawing.Size(314, 24);
            this.txt2pesos.TabIndex = 15;
            // 
            // txt20pesos
            // 
            this.txt20pesos.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt20pesos.Location = new System.Drawing.Point(173, 200);
            this.txt20pesos.Name = "txt20pesos";
            this.txt20pesos.ReadOnly = true;
            this.txt20pesos.Size = new System.Drawing.Size(314, 24);
            this.txt20pesos.TabIndex = 14;
            // 
            // txt10pesos
            // 
            this.txt10pesos.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt10pesos.Location = new System.Drawing.Point(173, 159);
            this.txt10pesos.Name = "txt10pesos";
            this.txt10pesos.ReadOnly = true;
            this.txt10pesos.Size = new System.Drawing.Size(314, 24);
            this.txt10pesos.TabIndex = 13;
            // 
            // txt5pesos
            // 
            this.txt5pesos.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt5pesos.Location = new System.Drawing.Point(173, 120);
            this.txt5pesos.Name = "txt5pesos";
            this.txt5pesos.ReadOnly = true;
            this.txt5pesos.Size = new System.Drawing.Size(314, 24);
            this.txt5pesos.TabIndex = 12;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(9, 377);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(140, 26);
            this.label12.TabIndex = 11;
            this.label12.Text = "Billetes de 500";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(9, 285);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(140, 26);
            this.label11.TabIndex = 10;
            this.label11.Text = "Billetes de 100";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(9, 331);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(140, 26);
            this.label10.TabIndex = 9;
            this.label10.Text = "Billetes de 200";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(9, 241);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(129, 26);
            this.label9.TabIndex = 8;
            this.label9.Text = "Billetes de 50";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(9, 198);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(129, 26);
            this.label8.TabIndex = 7;
            this.label8.Text = "Billetes de 20";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(9, 155);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(143, 26);
            this.label7.TabIndex = 6;
            this.label7.Text = "Monedas de 10";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 118);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(132, 26);
            this.label6.TabIndex = 5;
            this.label6.Text = "Monedas de 5";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 79);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(132, 26);
            this.label5.TabIndex = 4;
            this.label5.Text = "Monedas de 2";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 38);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(132, 26);
            this.label4.TabIndex = 3;
            this.label4.Text = "Monedas de 1";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btn500b);
            this.groupBox2.Controls.Add(this.btn20b);
            this.groupBox2.Controls.Add(this.btn50b);
            this.groupBox2.Controls.Add(this.btn2p);
            this.groupBox2.Controls.Add(this.btn200b);
            this.groupBox2.Controls.Add(this.btn1p);
            this.groupBox2.Controls.Add(this.btn100b);
            this.groupBox2.Controls.Add(this.btn5p);
            this.groupBox2.Controls.Add(this.btn10p);
            this.groupBox2.Controls.Add(this.labelIntroducido);
            this.groupBox2.Controls.Add(this.labelTotal);
            this.groupBox2.Controls.Add(this.groupBox4);
            this.groupBox2.Controls.Add(this.groupBox5);
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Controls.Add(this.imgDrPepper);
            this.groupBox2.Controls.Add(this.imgSprite);
            this.groupBox2.Controls.Add(this.imgCoca);
            this.groupBox2.Font = new System.Drawing.Font("Nunito SemiBold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(603, 27);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(805, 568);
            this.groupBox2.TabIndex = 23;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Interacción con el cajero";
            // 
            // btn500b
            // 
            this.btn500b.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn500b.ForeColor = System.Drawing.Color.Black;
            this.btn500b.Location = new System.Drawing.Point(461, 516);
            this.btn500b.Name = "btn500b";
            this.btn500b.Size = new System.Drawing.Size(94, 34);
            this.btn500b.TabIndex = 39;
            this.btn500b.Text = "Billete 500";
            this.btn500b.UseVisualStyleBackColor = true;
            this.btn500b.Click += new System.EventHandler(this.btn500b_Click);
            // 
            // btn20b
            // 
            this.btn20b.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn20b.ForeColor = System.Drawing.Color.Black;
            this.btn20b.Location = new System.Drawing.Point(512, 461);
            this.btn20b.Name = "btn20b";
            this.btn20b.Size = new System.Drawing.Size(94, 34);
            this.btn20b.TabIndex = 38;
            this.btn20b.Text = "Billete 20";
            this.btn20b.UseVisualStyleBackColor = true;
            this.btn20b.Click += new System.EventHandler(this.btn20b_Click);
            // 
            // btn50b
            // 
            this.btn50b.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn50b.ForeColor = System.Drawing.Color.Black;
            this.btn50b.Location = new System.Drawing.Point(612, 461);
            this.btn50b.Name = "btn50b";
            this.btn50b.Size = new System.Drawing.Size(94, 34);
            this.btn50b.TabIndex = 36;
            this.btn50b.Text = "Billete 50";
            this.btn50b.UseVisualStyleBackColor = true;
            this.btn50b.Click += new System.EventHandler(this.btn50b_Click);
            // 
            // btn2p
            // 
            this.btn2p.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn2p.ForeColor = System.Drawing.Color.Black;
            this.btn2p.Location = new System.Drawing.Point(212, 461);
            this.btn2p.Name = "btn2p";
            this.btn2p.Size = new System.Drawing.Size(94, 34);
            this.btn2p.TabIndex = 33;
            this.btn2p.Text = "2 Pesos";
            this.btn2p.UseVisualStyleBackColor = true;
            this.btn2p.Click += new System.EventHandler(this.btn2p_Click);
            // 
            // btn200b
            // 
            this.btn200b.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn200b.ForeColor = System.Drawing.Color.Black;
            this.btn200b.Location = new System.Drawing.Point(361, 516);
            this.btn200b.Name = "btn200b";
            this.btn200b.Size = new System.Drawing.Size(94, 34);
            this.btn200b.TabIndex = 37;
            this.btn200b.Text = "Billete 200";
            this.btn200b.UseVisualStyleBackColor = true;
            this.btn200b.Click += new System.EventHandler(this.btn200b_Click);
            // 
            // btn1p
            // 
            this.btn1p.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn1p.ForeColor = System.Drawing.Color.Black;
            this.btn1p.Location = new System.Drawing.Point(112, 461);
            this.btn1p.Name = "btn1p";
            this.btn1p.Size = new System.Drawing.Size(94, 34);
            this.btn1p.TabIndex = 35;
            this.btn1p.Text = "1 Peso";
            this.btn1p.UseVisualStyleBackColor = true;
            this.btn1p.Click += new System.EventHandler(this.btn1p_Click);
            // 
            // btn100b
            // 
            this.btn100b.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn100b.ForeColor = System.Drawing.Color.Black;
            this.btn100b.Location = new System.Drawing.Point(261, 516);
            this.btn100b.Name = "btn100b";
            this.btn100b.Size = new System.Drawing.Size(94, 34);
            this.btn100b.TabIndex = 34;
            this.btn100b.Text = "Billete 100";
            this.btn100b.UseVisualStyleBackColor = true;
            this.btn100b.Click += new System.EventHandler(this.btn100b_Click);
            // 
            // btn5p
            // 
            this.btn5p.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn5p.ForeColor = System.Drawing.Color.Black;
            this.btn5p.Location = new System.Drawing.Point(312, 461);
            this.btn5p.Name = "btn5p";
            this.btn5p.Size = new System.Drawing.Size(94, 34);
            this.btn5p.TabIndex = 31;
            this.btn5p.Text = "5 Pesos";
            this.btn5p.UseVisualStyleBackColor = true;
            this.btn5p.Click += new System.EventHandler(this.btn5p_Click);
            // 
            // btn10p
            // 
            this.btn10p.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn10p.ForeColor = System.Drawing.Color.Black;
            this.btn10p.Location = new System.Drawing.Point(412, 461);
            this.btn10p.Name = "btn10p";
            this.btn10p.Size = new System.Drawing.Size(94, 34);
            this.btn10p.TabIndex = 29;
            this.btn10p.Text = "10 Pesos";
            this.btn10p.UseVisualStyleBackColor = true;
            this.btn10p.Click += new System.EventHandler(this.btn10p_Click);
            // 
            // labelIntroducido
            // 
            this.labelIntroducido.AutoSize = true;
            this.labelIntroducido.Location = new System.Drawing.Point(193, 404);
            this.labelIntroducido.Name = "labelIntroducido";
            this.labelIntroducido.Size = new System.Drawing.Size(170, 26);
            this.labelIntroducido.TabIndex = 28;
            this.labelIntroducido.Text = "Introducido: 0.00$";
            // 
            // labelTotal
            // 
            this.labelTotal.AutoSize = true;
            this.labelTotal.Location = new System.Drawing.Point(467, 404);
            this.labelTotal.Name = "labelTotal";
            this.labelTotal.Size = new System.Drawing.Size(115, 26);
            this.labelTotal.TabIndex = 27;
            this.labelTotal.Text = "Total: 0.00$";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.existenciaSprite);
            this.groupBox4.Controls.Add(this.codigoSprite);
            this.groupBox4.Controls.Add(this.nombreSprite);
            this.groupBox4.Controls.Add(this.precioSprite);
            this.groupBox4.Font = new System.Drawing.Font("Nunito SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.ForeColor = System.Drawing.Color.GhostWhite;
            this.groupBox4.Location = new System.Drawing.Point(198, 161);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(584, 100);
            this.groupBox4.TabIndex = 25;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Información Producto";
            // 
            // existenciaSprite
            // 
            this.existenciaSprite.AutoSize = true;
            this.existenciaSprite.Location = new System.Drawing.Point(270, 56);
            this.existenciaSprite.Name = "existenciaSprite";
            this.existenciaSprite.Size = new System.Drawing.Size(87, 21);
            this.existenciaSprite.TabIndex = 5;
            this.existenciaSprite.Text = "Existencia:";
            // 
            // codigoSprite
            // 
            this.codigoSprite.AutoSize = true;
            this.codigoSprite.Location = new System.Drawing.Point(270, 35);
            this.codigoSprite.Name = "codigoSprite";
            this.codigoSprite.Size = new System.Drawing.Size(101, 21);
            this.codigoSprite.TabIndex = 4;
            this.codigoSprite.Text = "Código: B03";
            // 
            // nombreSprite
            // 
            this.nombreSprite.AutoSize = true;
            this.nombreSprite.Location = new System.Drawing.Point(6, 56);
            this.nombreSprite.Name = "nombreSprite";
            this.nombreSprite.Size = new System.Drawing.Size(172, 21);
            this.nombreSprite.TabIndex = 3;
            this.nombreSprite.Text = "Nombre: Sprite de lata";
            // 
            // precioSprite
            // 
            this.precioSprite.AutoSize = true;
            this.precioSprite.Location = new System.Drawing.Point(6, 35);
            this.precioSprite.Name = "precioSprite";
            this.precioSprite.Size = new System.Drawing.Size(129, 21);
            this.precioSprite.TabIndex = 2;
            this.precioSprite.Text = "Precio: 11 pesos";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.existenciaPepper);
            this.groupBox5.Controls.Add(this.codigoPepper);
            this.groupBox5.Controls.Add(this.nombrePepper);
            this.groupBox5.Controls.Add(this.precioPepper);
            this.groupBox5.Font = new System.Drawing.Font("Nunito SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.ForeColor = System.Drawing.Color.GhostWhite;
            this.groupBox5.Location = new System.Drawing.Point(198, 288);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(584, 100);
            this.groupBox5.TabIndex = 25;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Información Producto";
            // 
            // existenciaPepper
            // 
            this.existenciaPepper.AutoSize = true;
            this.existenciaPepper.Location = new System.Drawing.Point(270, 57);
            this.existenciaPepper.Name = "existenciaPepper";
            this.existenciaPepper.Size = new System.Drawing.Size(87, 21);
            this.existenciaPepper.TabIndex = 6;
            this.existenciaPepper.Text = "Existencia:";
            // 
            // codigoPepper
            // 
            this.codigoPepper.AutoSize = true;
            this.codigoPepper.Font = new System.Drawing.Font("Nunito SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.codigoPepper.Location = new System.Drawing.Point(270, 36);
            this.codigoPepper.Name = "codigoPepper";
            this.codigoPepper.Size = new System.Drawing.Size(99, 21);
            this.codigoPepper.TabIndex = 5;
            this.codigoPepper.Text = "Código: F02";
            // 
            // nombrePepper
            // 
            this.nombrePepper.AutoSize = true;
            this.nombrePepper.Font = new System.Drawing.Font("Nunito SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nombrePepper.Location = new System.Drawing.Point(6, 57);
            this.nombrePepper.Name = "nombrePepper";
            this.nombrePepper.Size = new System.Drawing.Size(215, 21);
            this.nombrePepper.TabIndex = 4;
            this.nombrePepper.Text = "Nombre: Refresco Dr Pepper";
            // 
            // precioPepper
            // 
            this.precioPepper.AutoSize = true;
            this.precioPepper.Font = new System.Drawing.Font("Nunito SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.precioPepper.Location = new System.Drawing.Point(6, 36);
            this.precioPepper.Name = "precioPepper";
            this.precioPepper.Size = new System.Drawing.Size(129, 21);
            this.precioPepper.TabIndex = 3;
            this.precioPepper.Text = "Precio: 12 pesos";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.existenciaCoca);
            this.groupBox3.Controls.Add(this.codigoCoca);
            this.groupBox3.Controls.Add(this.nombreCoca);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.precioCoca);
            this.groupBox3.Font = new System.Drawing.Font("Nunito SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.ForeColor = System.Drawing.Color.White;
            this.groupBox3.Location = new System.Drawing.Point(198, 42);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(584, 100);
            this.groupBox3.TabIndex = 24;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Información Producto";
            // 
            // existenciaCoca
            // 
            this.existenciaCoca.AutoSize = true;
            this.existenciaCoca.Location = new System.Drawing.Point(269, 58);
            this.existenciaCoca.Name = "existenciaCoca";
            this.existenciaCoca.Size = new System.Drawing.Size(87, 21);
            this.existenciaCoca.TabIndex = 4;
            this.existenciaCoca.Text = "Existencia:";
            // 
            // codigoCoca
            // 
            this.codigoCoca.AutoSize = true;
            this.codigoCoca.Location = new System.Drawing.Point(270, 37);
            this.codigoCoca.Name = "codigoCoca";
            this.codigoCoca.Size = new System.Drawing.Size(102, 21);
            this.codigoCoca.TabIndex = 3;
            this.codigoCoca.Text = "Código: A01";
            // 
            // nombreCoca
            // 
            this.nombreCoca.AutoSize = true;
            this.nombreCoca.ForeColor = System.Drawing.Color.White;
            this.nombreCoca.Location = new System.Drawing.Point(6, 58);
            this.nombreCoca.Name = "nombreCoca";
            this.nombreCoca.Size = new System.Drawing.Size(200, 21);
            this.nombreCoca.TabIndex = 2;
            this.nombreCoca.Text = "Nombre: Coca cola de lata";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 71);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(0, 21);
            this.label14.TabIndex = 1;
            // 
            // precioCoca
            // 
            this.precioCoca.AutoSize = true;
            this.precioCoca.Location = new System.Drawing.Point(6, 37);
            this.precioCoca.Name = "precioCoca";
            this.precioCoca.Size = new System.Drawing.Size(129, 21);
            this.precioCoca.TabIndex = 0;
            this.precioCoca.Text = "Precio: 13 pesos";
            // 
            // imgDrPepper
            // 
            this.imgDrPepper.Cursor = System.Windows.Forms.Cursors.Hand;
            this.imgDrPepper.Image = global::CajeroForms.Properties.Resources.dr_pepper;
            this.imgDrPepper.Location = new System.Drawing.Point(6, 287);
            this.imgDrPepper.Name = "imgDrPepper";
            this.imgDrPepper.Size = new System.Drawing.Size(142, 101);
            this.imgDrPepper.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.imgDrPepper.TabIndex = 26;
            this.imgDrPepper.TabStop = false;
            // 
            // imgSprite
            // 
            this.imgSprite.Cursor = System.Windows.Forms.Cursors.Hand;
            this.imgSprite.Image = global::CajeroForms.Properties.Resources.sprite_de_lata;
            this.imgSprite.Location = new System.Drawing.Point(6, 164);
            this.imgSprite.Name = "imgSprite";
            this.imgSprite.Size = new System.Drawing.Size(142, 101);
            this.imgSprite.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.imgSprite.TabIndex = 25;
            this.imgSprite.TabStop = false;
            // 
            // imgCoca
            // 
            this.imgCoca.Cursor = System.Windows.Forms.Cursors.Hand;
            this.imgCoca.Image = global::CajeroForms.Properties.Resources.coca_de_lata;
            this.imgCoca.Location = new System.Drawing.Point(6, 42);
            this.imgCoca.Name = "imgCoca";
            this.imgCoca.Size = new System.Drawing.Size(142, 101);
            this.imgCoca.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.imgCoca.TabIndex = 24;
            this.imgCoca.TabStop = false;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.labelPantalla);
            this.groupBox6.Font = new System.Drawing.Font("Nunito SemiBold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.ForeColor = System.Drawing.SystemColors.Menu;
            this.groupBox6.Location = new System.Drawing.Point(12, 611);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(521, 100);
            this.groupBox6.TabIndex = 24;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Pantalla";
            // 
            // labelPantalla
            // 
            this.labelPantalla.AutoSize = true;
            this.labelPantalla.Location = new System.Drawing.Point(6, 45);
            this.labelPantalla.Name = "labelPantalla";
            this.labelPantalla.Size = new System.Drawing.Size(71, 26);
            this.labelPantalla.TabIndex = 0;
            this.labelPantalla.Text = "Estado";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.labelMonedero);
            this.groupBox7.Font = new System.Drawing.Font("Nunito SemiBold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox7.ForeColor = System.Drawing.SystemColors.Menu;
            this.groupBox7.Location = new System.Drawing.Point(603, 611);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(805, 100);
            this.groupBox7.TabIndex = 25;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Monedero";
            // 
            // labelMonedero
            // 
            this.labelMonedero.AutoSize = true;
            this.labelMonedero.Location = new System.Drawing.Point(6, 45);
            this.labelMonedero.Name = "labelMonedero";
            this.labelMonedero.Size = new System.Drawing.Size(71, 26);
            this.labelMonedero.TabIndex = 0;
            this.labelMonedero.Text = "Estado";
            // 
            // txtInput
            // 
            this.txtInput.BackColor = System.Drawing.Color.DarkBlue;
            this.txtInput.Font = new System.Drawing.Font("Unispace", 81.74999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInput.ForeColor = System.Drawing.Color.White;
            this.txtInput.Location = new System.Drawing.Point(1426, 37);
            this.txtInput.Name = "txtInput";
            this.txtInput.Size = new System.Drawing.Size(285, 138);
            this.txtInput.TabIndex = 26;
            this.txtInput.TextChanged += new System.EventHandler(this.txtInput_TextChanged);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Black;
            this.button1.Font = new System.Drawing.Font("Nunito", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(1426, 188);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(91, 69);
            this.button1.TabIndex = 27;
            this.button1.Text = "A";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Black;
            this.button2.Font = new System.Drawing.Font("Nunito", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(1426, 413);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(91, 69);
            this.button2.TabIndex = 28;
            this.button2.Text = "D";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Black;
            this.button3.Font = new System.Drawing.Font("Nunito", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(1426, 337);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(91, 69);
            this.button3.TabIndex = 29;
            this.button3.Text = "C";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Black;
            this.button4.Font = new System.Drawing.Font("Nunito", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(1426, 263);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(91, 69);
            this.button4.TabIndex = 30;
            this.button4.Text = "B";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Black;
            this.button5.Font = new System.Drawing.Font("Nunito", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(1426, 563);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(91, 69);
            this.button5.TabIndex = 31;
            this.button5.Text = "F";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Black;
            this.button6.Font = new System.Drawing.Font("Nunito", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(1426, 488);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(91, 69);
            this.button6.TabIndex = 32;
            this.button6.Text = "E";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Black;
            this.button7.Font = new System.Drawing.Font("Nunito", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(1523, 188);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(91, 69);
            this.button7.TabIndex = 33;
            this.button7.Text = "1";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Black;
            this.button8.Font = new System.Drawing.Font("Nunito", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Location = new System.Drawing.Point(1620, 188);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(91, 69);
            this.button8.TabIndex = 34;
            this.button8.Text = "2";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.Black;
            this.button9.Font = new System.Drawing.Font("Nunito", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.White;
            this.button9.Location = new System.Drawing.Point(1620, 337);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(91, 69);
            this.button9.TabIndex = 35;
            this.button9.Text = "6";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.Black;
            this.button10.Font = new System.Drawing.Font("Nunito", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.Color.White;
            this.button10.Location = new System.Drawing.Point(1523, 338);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(91, 69);
            this.button10.TabIndex = 36;
            this.button10.Text = "5";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.Black;
            this.button11.Font = new System.Drawing.Font("Nunito", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.ForeColor = System.Drawing.Color.White;
            this.button11.Location = new System.Drawing.Point(1523, 563);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(91, 69);
            this.button11.TabIndex = 37;
            this.button11.Text = "CLR";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // btnSubmit
            // 
            this.btnSubmit.BackColor = System.Drawing.Color.Black;
            this.btnSubmit.Font = new System.Drawing.Font("Nunito", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmit.ForeColor = System.Drawing.Color.White;
            this.btnSubmit.Location = new System.Drawing.Point(1620, 563);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(91, 69);
            this.btnSubmit.TabIndex = 38;
            this.btnSubmit.Text = "SUB";
            this.btnSubmit.UseVisualStyleBackColor = false;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.Black;
            this.button13.Font = new System.Drawing.Font("Nunito", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.ForeColor = System.Drawing.Color.White;
            this.button13.Location = new System.Drawing.Point(1620, 263);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(91, 69);
            this.button13.TabIndex = 39;
            this.button13.Text = "4";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.Black;
            this.button14.Font = new System.Drawing.Font("Nunito", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.ForeColor = System.Drawing.Color.White;
            this.button14.Location = new System.Drawing.Point(1523, 263);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(91, 69);
            this.button14.TabIndex = 40;
            this.button14.Text = "3";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.Black;
            this.button15.Font = new System.Drawing.Font("Nunito", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15.ForeColor = System.Drawing.Color.White;
            this.button15.Location = new System.Drawing.Point(1620, 413);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(91, 69);
            this.button15.TabIndex = 41;
            this.button15.Text = "8";
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.Black;
            this.button16.Font = new System.Drawing.Font("Nunito", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button16.ForeColor = System.Drawing.Color.White;
            this.button16.Location = new System.Drawing.Point(1523, 413);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(91, 69);
            this.button16.TabIndex = 42;
            this.button16.Text = "7";
            this.button16.UseVisualStyleBackColor = false;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.Black;
            this.button17.Font = new System.Drawing.Font("Nunito", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button17.ForeColor = System.Drawing.Color.White;
            this.button17.Location = new System.Drawing.Point(1620, 488);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(91, 69);
            this.button17.TabIndex = 43;
            this.button17.Text = "0";
            this.button17.UseVisualStyleBackColor = false;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.Black;
            this.button18.Font = new System.Drawing.Font("Nunito", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button18.ForeColor = System.Drawing.Color.White;
            this.button18.Location = new System.Drawing.Point(1523, 488);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(91, 69);
            this.button18.TabIndex = 44;
            this.button18.Text = "9";
            this.button18.UseVisualStyleBackColor = false;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 485);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(205, 26);
            this.label1.TabIndex = 45;
            this.label1.Text = "Dinero total de la caja:";
            // 
            // labelDineroTotal
            // 
            this.labelDineroTotal.AutoSize = true;
            this.labelDineroTotal.Location = new System.Drawing.Point(220, 485);
            this.labelDineroTotal.Name = "labelDineroTotal";
            this.labelDineroTotal.Size = new System.Drawing.Size(23, 26);
            this.labelDineroTotal.TabIndex = 46;
            this.labelDineroTotal.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Indigo;
            this.ClientSize = new System.Drawing.Size(1734, 745);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtInput);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Cajero automático";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgDrPepper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgSprite)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgCoca)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txt50pesos;
        private System.Windows.Forms.TextBox txt500pesos;
        private System.Windows.Forms.TextBox txt200pesos;
        private System.Windows.Forms.TextBox txt100pesos;
        private System.Windows.Forms.TextBox txt1peso;
        private System.Windows.Forms.TextBox txt2pesos;
        private System.Windows.Forms.TextBox txt20pesos;
        private System.Windows.Forms.TextBox txt10pesos;
        private System.Windows.Forms.TextBox txt5pesos;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.PictureBox imgCoca;
        private System.Windows.Forms.PictureBox imgSprite;
        private System.Windows.Forms.PictureBox imgDrPepper;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label nombreSprite;
        private System.Windows.Forms.Label precioSprite;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label nombrePepper;
        private System.Windows.Forms.Label precioPepper;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label nombreCoca;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label precioCoca;
        private System.Windows.Forms.Button btn500b;
        private System.Windows.Forms.Button btn20b;
        private System.Windows.Forms.Button btn50b;
        private System.Windows.Forms.Button btn2p;
        private System.Windows.Forms.Button btn200b;
        private System.Windows.Forms.Button btn1p;
        private System.Windows.Forms.Button btn100b;
        private System.Windows.Forms.Button btn5p;
        private System.Windows.Forms.Button btn10p;
        private System.Windows.Forms.Label labelIntroducido;
        private System.Windows.Forms.Label labelTotal;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label labelPantalla;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label labelMonedero;
        private System.Windows.Forms.TextBox txtInput;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Label codigoSprite;
        private System.Windows.Forms.Label codigoPepper;
        private System.Windows.Forms.Label codigoCoca;
        private System.Windows.Forms.Label existenciaSprite;
        private System.Windows.Forms.Label existenciaPepper;
        private System.Windows.Forms.Label existenciaCoca;
        private System.Windows.Forms.Label labelDineroTotal;
        private System.Windows.Forms.Label label1;
    }
}

